import { DragDropFileUploadDirective } from './drag-drop-file-upload.directive';

describe('DragDropFileUploadDirective', () => {
  it('should create an instance', () => {
    const directive = new DragDropFileUploadDirective();
    expect(directive).toBeTruthy();
  });
});
