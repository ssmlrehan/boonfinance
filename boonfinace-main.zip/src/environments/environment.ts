export const environment = {
  // apiLocation: 'http://localhost:8080',
  // coreApi: 'http://localhost:8080/api/v1/',
  apiLocation: 'https://api.boonfinance.ai/',
  coreApi: 'https://api.boonfinance.ai/api/v1/',
  production: false
};