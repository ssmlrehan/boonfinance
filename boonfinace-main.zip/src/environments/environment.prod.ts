export const environment = {
  apiLocation: 'https://api.boonfinance.ai/',
  coreApi: 'https://api.boonfinance.ai/api/v1/',
  production: true
}; 